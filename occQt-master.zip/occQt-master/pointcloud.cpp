#include "pointcloud.h"

pointCloud::pointCloud(QWidget* parent, Handle(AIS_InteractiveContext) Context)
    : QWidget(parent)
{
    myContext = Context;
}

// filtering
pcl::PointCloud<pcl::PointXYZ>::Ptr pointCloud::voxelGrid(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud){
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_voxel(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::VoxelGrid<pcl::PointXYZ> voxel;
    voxel.setInputCloud(cloud);
    voxel.setLeafSize(0.01f, 0.01f, 0.01f);
    voxel.filter(*cloud_voxel);
    return cloud_voxel;
}
pcl::PointCloud<pcl::PointXYZ>::Ptr pointCloud::statisticalOutlierRemoval(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud){
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_stat(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::StatisticalOutlierRemoval<pcl::PointXYZ> sor;
    sor.setInputCloud(cloud);
    sor.setMeanK(50);
    sor.setStddevMulThresh(0.7);
    sor.filter(*cloud_stat);
    return cloud_stat;
}
pcl::PointCloud<pcl::PointXYZ>::Ptr pointCloud::radiusOutlierRemoval(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud){
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_radius(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::RadiusOutlierRemoval<pcl::PointXYZ> rad;
    rad.setInputCloud(cloud);
    rad.setRadiusSearch(0.05);
    rad.setMinNeighborsInRadius(10);
    rad.filter(*cloud_radius);
    return cloud_radius;
}

// segmentation
void pointCloud::planeSegmentation(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud){
    pcl::ModelCoefficients::Ptr coefficients (new pcl::ModelCoefficients);
    pcl::PointIndices::Ptr inliers (new pcl::PointIndices);
    pcl::SACSegmentation<pcl::PointXYZ> seg;
    seg.setOptimizeCoefficients(true);
    seg.setModelType(pcl::SACMODEL_PLANE);
    seg.setMethodType(pcl::SAC_RANSAC);
    seg.setDistanceThreshold(0.08);
    seg.setInputCloud(cloud);
    seg.segment(*inliers, *coefficients);

    pcl::PointCloud<pcl::PointXYZ>::Ptr plane_cloud (new pcl::PointCloud<pcl::PointXYZ>);
    pcl::ExtractIndices<pcl::PointXYZ> extract;
    extract.setInputCloud(cloud);
    extract.setIndices(inliers);
    extract.filter(*plane_cloud);


    pcl::PointCloud<pcl::PointXYZ>::Ptr non_plane_cloud (new pcl::PointCloud<pcl::PointXYZ>);
    extract.setNegative(true);
    extract.setInputCloud(cloud);
    extract.filter(*non_plane_cloud);
    QVector<pcl::PointCloud<pcl::PointXYZ>::Ptr> clouds;
    clouds.push_back(plane_cloud);
    clouds.push_back(non_plane_cloud);
}
void pointCloud::clusterSegmentation(void){
    //    pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ>);
    //    tree->setInputCloud (non_plane_cloud);

    //    std::vector<pcl::PointIndices> cluster_indices;
    //    pcl::EuclideanClusterExtraction<pcl::PointXYZ> ec;
    //    ec.setClusterTolerance(0.05);
    //    ec.setMinClusterSize(1000);
    //    ec.setMaxClusterSize(2500000);
    //    ec.setSearchMethod(tree);
    //    ec.setInputCloud(non_plane_cloud);
    //    ec.extract(cluster_indices);
}

// rebuild
void pointCloud::greedyTriangulation(void){

}
void pointCloud::poissonRebuild(void){

}
