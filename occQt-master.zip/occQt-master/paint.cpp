#include "paint.h"

paint::paint(QWidget* parent, Handle(AIS_InteractiveContext) Context, Handle(AIS_Manipulator) Manipulator)
    : QWidget(parent)
{
    myColor = Quantity_NOC_RED;
    myWidth = 2.0;
    myContext = Context;
    aManipulator = Manipulator;
    myTransparency = 0.0;
}

//void paint::Line(void){

//}

//void paint::Face(void){

//}

void paint::setColor(void){
    QColor color = QColorDialog::getColor(Qt::white, this);
    QRgb rgb = color.rgb();
    Quantity_Color customColor((qRed(rgb) / 255.0),(qGreen(rgb) / 255.0),(qBlue(rgb) / 255.0),Quantity_TOC_RGB);
    myColor = FindClosestColor(customColor);
}

void paint::setWidth(double width){
    myWidth = width;
}

void paint::setTransparency(double transparency){
    myTransparency = static_cast<double>(transparency) / 100.0;
}

Quantity_NameOfColor paint::FindClosestColor(const Quantity_Color& color) {
    Standard_Real minDist = RealLast();
    Quantity_NameOfColor closestColor = Quantity_NOC_BLACK;

    for (int i = 0; i < Quantity_NOC_WHITE; i++) {
        Quantity_NameOfColor current = static_cast<Quantity_NameOfColor>(i);
        Quantity_Color predefinedColor(current);

        Standard_Real dist =
            pow(color.Red() - predefinedColor.Red(), 2) +
            pow(color.Green() - predefinedColor.Green(), 2) +
            pow(color.Blue() - predefinedColor.Blue(), 2);

        if (dist < minDist) {
            minDist = dist;
            closestColor = current;
        }
    }
    return closestColor;
}

Point::Point()
{
}

Handle(AIS_Shape) Point::addPoint(gp_Pnt point){
    TopoDS_Shape aShape = BRepBuilderAPI_MakeVertex(point);
    Handle(AIS_Shape) aisShpae = new AIS_Shape(aShape);

    Handle(Prs3d_Drawer) drawer = aisShpae->Attributes();

    drawer->SetPointAspect(new Prs3d_PointAspect(
        Aspect_TOM_POINT,
        myColor,
        myWidth));
//    drawer->SetDisplayMode(0);
//    drawer->SetTransparency(myTransparency);

    return aisShpae;
}

QVector<Handle(AIS_Shape)> Point::deletePoint(void){
    QVector<Handle(AIS_Shape)> myShapes;
    myContext->InitSelected();

    while (myContext->MoreSelected()) {
        Handle(AIS_InteractiveObject) selectedObject = myContext->SelectedInteractive();
        Handle(AIS_Shape) selectedShape = Handle(AIS_Shape)::DownCast(selectedObject);
        if (!selectedShape.IsNull()) {
            myShapes.push_back(selectedShape);
        }
        myContext->NextSelected();
    }
    return myShapes;
}
QVector<Handle(AIS_Shape)> Point::movingPoint(gp_Pnt point){
    myContext->InitSelected();
    QVector<Handle(AIS_Shape)> myShapes;
    Handle(AIS_InteractiveObject) selectedObject = myContext->SelectedInteractive();
    Handle(AIS_Shape) selectedShape = Handle(AIS_Shape)::DownCast(selectedObject);
    if (!selectedShape.IsNull()) {
        myShapes.push_back(selectedShape);
    }
    myShapes.push_back(addPoint(point));
    return myShapes;
}
void Point::drawTempPoint(gp_Pnt point){
    if(!tempPoint.IsNull()){
        myContext->Remove(tempPoint,Standard_True);
    }
    TopoDS_Shape aShape = BRepBuilderAPI_MakeVertex(point);
    tempPoint = new AIS_Shape(aShape);

    Handle(Prs3d_Drawer) drawer = tempPoint->Attributes();

    drawer->SetPointAspect(new Prs3d_PointAspect(
        Aspect_TOM_POINT,
        Quantity_NOC_ANTIQUEWHITE,
        myWidth));
    myContext->Display(tempPoint,Standard_True);
}

bool Point::Manipulator(void){
    myContext->InitSelected();

    Handle(AIS_InteractiveObject) selectedObject = myContext->SelectedInteractive();
    Handle(AIS_Shape) selectedShape = Handle(AIS_Shape)::DownCast(selectedObject);

    if (!selectedShape.IsNull()) {
        aManipulator->Attach(selectedShape);
        myContext->UpdateCurrentViewer();
        return true;
    }
    else
        return false;
}

Handle(AIS_Shape) Point::reDrawPoint(Handle(AIS_Shape) selectedShape){

    gp_Trsf aTrsf;
    TopoDS_Shape shape;
    if (selectedShape->HasTransformation()) {
        aTrsf = selectedShape->LocalTransformation();
        qDebug()<<"ok";
    }
//    if (Abs(aTrsf.ScaleFactor() - 1.0) > Precision::Confusion()) {
//        BRepBuilderAPI_Transform aBRepTrsf(aTrsf);
//        shape = aBRepTrsf.Shape();
//    }
//    else
//        shape = selectedShape->Shape().Moved(aTrsf);
    BRepBuilderAPI_Transform aBRepTrsf(selectedShape->Shape(), aTrsf, Standard_True);
    if (aBRepTrsf.IsDone()) {
        shape = aBRepTrsf.Shape();

    }
    Handle(AIS_Shape) aisShpae = new AIS_Shape(shape);
    Handle(Prs3d_Drawer) drawer = aisShpae->Attributes();
    if(shape.ShapeType() == TopAbs_VERTEX) drawer->SetPointAspect(new Prs3d_PointAspect(Aspect_TOM_POINT, myColor, myWidth));
    else if(shape.ShapeType() == TopAbs_EDGE || shape.ShapeType() == TopAbs_WIRE)
        drawer->SetWireAspect(new Prs3d_LineAspect(myColor, Aspect_TOL_SOLID, myWidth));
    else if(shape.ShapeType() == TopAbs_SOLID) aisShpae->SetColor(myColor);
    else{
        aisShpae->SetColor(myColor);
        aisShpae->SetTransparency(myTransparency);
    }
    if (!aisShpae.IsNull()) return aisShpae;
    else return nullptr;
}

Line::Line(void){}

Handle(AIS_Shape) Line::addLine(gp_Pnt firstPoint, gp_Pnt SecondPoint){
    if (firstPoint.IsEqual(SecondPoint,1e-6)){
        return nullptr;
    }
    TopoDS_Shape aShape = BRepBuilderAPI_MakeEdge(firstPoint, SecondPoint);
    Handle(AIS_Shape) aisShpae = new AIS_Shape(aShape);

    Handle(Prs3d_Drawer) drawer = aisShpae->Attributes();

    drawer->SetWireAspect(new Prs3d_LineAspect(myColor, Aspect_TOL_SOLID, myWidth));
    return aisShpae;
}

Handle(AIS_Shape) Line::makeWire(QVector<Handle(AIS_Shape)> Lines){
    BRepBuilderAPI_MakeWire wireMaker;
    for (auto it = Lines.begin(); it != Lines.end(); ++it) {
        //myContext->Remove((*it),Standard_True);
        const TopoDS_Shape shape = (*it)->Shape();
        if (shape.ShapeType() == TopAbs_EDGE)
        {
            TopoDS_Edge edge = TopoDS::Edge(shape);
            wireMaker.Add(edge);
        }
    }
    if(wireMaker.IsDone()){
        TopoDS_Wire wire = wireMaker.Wire();
        Handle(AIS_Shape) aisWire = new AIS_Shape(wire);
        Handle(Prs3d_Drawer) drawer = aisWire->Attributes();
        drawer->SetWireAspect(new Prs3d_LineAspect(myColor, Aspect_TOL_SOLID, myWidth));
        //qDebug()<<"wire ok";
        return aisWire;
    }
    return nullptr;
}
Handle(AIS_Shape) Line::makeLofting(void){

    myContext->InitSelected();
    std::vector<TopoDS_Face> selectedFaces;
    std::vector<TopoDS_Wire> wires;
    while (myContext->MoreSelected()) {
        Handle(AIS_InteractiveObject) selectedObject = myContext->SelectedInteractive();
        Handle(AIS_Shape) selectedShape = Handle(AIS_Shape)::DownCast(selectedObject);
        if (!selectedShape.IsNull()) {
            const TopoDS_Shape& shape = selectedShape->Shape();
            TopAbs_ShapeEnum shapeType = shape.ShapeType();
            if (shapeType == TopAbs_FACE){
                TopoDS_Face face = TopoDS::Face(shape);
                selectedFaces.push_back(face);
                TopExp_Explorer wireExp(face, TopAbs_WIRE);
                while (wireExp.More()) {
                    TopoDS_Wire wire = TopoDS::Wire(wireExp.Current());
                    wires.push_back(wire);
                    wireExp.Next();
                }
            }

            else if (shapeType == TopAbs_WIRE)
                wires.push_back(TopoDS::Wire(shape));

        }
        myContext->NextSelected();
    }

    if (wires.size() < 2) return nullptr;

    // lofting
    TopoDS_Compound compound;
    BRep_Builder builder;
    builder.MakeCompound(compound);
    for (size_t i = 0; i < wires.size() - 1; ++i) {
        BRepOffsetAPI_ThruSections loft(Standard_False);
        qDebug()<<i;
        loft.AddWire(wires[i]);
        loft.AddWire(wires[i + 1]);
        loft.Build();
        if (loft.IsDone()) {
            TopoDS_Shape loftedShape = loft.Shape();
            BRepMesh_IncrementalMesh mesher(loftedShape, 10);
            mesher.Perform();
            for (TopExp_Explorer faceExplorer(loftedShape, TopAbs_FACE); faceExplorer.More(); faceExplorer.Next()) {
                TopoDS_Face face = TopoDS::Face(faceExplorer.Current());
                TopLoc_Location location;
                Handle(Poly_Triangulation) triangulation = BRep_Tool::Triangulation(face, location);
                if (!triangulation.IsNull()) {

                    for (Standard_Integer i = 1; i <= triangulation->NbTriangles(); ++i) {
                        Poly_Triangle triangle = triangulation->Triangle(i);
                        Standard_Integer n1, n2, n3;
                        triangle.Get(n1, n2, n3);

                        gp_Pnt p1 = triangulation->Node(n1);
                        gp_Pnt p2 = triangulation->Node(n2);
                        gp_Pnt p3 = triangulation->Node(n3);

                        BRepBuilderAPI_MakeEdge edge1(p1, p2);
                        BRepBuilderAPI_MakeEdge edge2(p2, p3);
                        BRepBuilderAPI_MakeEdge edge3(p3, p1);

                        BRepBuilderAPI_MakeWire wireMaker;
                        wireMaker.Add(edge1.Edge());
                        wireMaker.Add(edge2.Edge());
                        wireMaker.Add(edge3.Edge());
                        TopoDS_Wire wire = wireMaker.Wire();

                        BRepBuilderAPI_MakeFace faceMaker(wire);
                        if (faceMaker.IsDone()) {

                            TopoDS_Face face = faceMaker.Face();
                            builder.Add(compound, face);}

                    }
                }
            }
        }
    }

    TopoDS_Shape combinedShape = compound;
    Handle(AIS_Shape) aisShape = new AIS_Shape(combinedShape);
    aisShape->SetColor(myColor);
    aisShape->SetTransparency(myTransparency);

    return aisShape;
}

Handle(AIS_Shape) Line::wireToFace(Handle(AIS_Shape) selectedShape){
    const TopoDS_Shape& shape = selectedShape->Shape();
    if(shape.ShapeType() == TopAbs_WIRE){
        TopoDS_Wire wire = TopoDS::Wire(shape);
        Face *myFace = new Face();
        Handle(AIS_Shape) face = myFace->addFace(wire);
        return face;
    }
    return nullptr;
}

QVector<gp_Pnt> Line::extractVertexCoordinates(const QVector<Handle(AIS_Shape)>& shapes) {
    QVector<gp_Pnt> result;

    for (const auto& shapeHandle : shapes) {
        if (shapeHandle.IsNull()) continue;

        const TopoDS_Shape& topoShape = shapeHandle->Shape();
        if (topoShape.ShapeType() == TopAbs_VERTEX) {
            TopoDS_Vertex vertex = TopoDS::Vertex(topoShape);
            gp_Pnt point = BRep_Tool::Pnt(vertex);
            result.append(point);
        }
    }

    return result;
}

QVector<Handle(AIS_Shape)> Line::convexHull(QVector<gp_Pnt> Points, char coordinate){
    char axis = coordinate;

    QVector<Handle(AIS_Shape)> shapes;

    std::vector<double> values;
    for (const auto& point : Points) {
        double val;
        switch (axis) {
        case 'x':
            val = point.X();
            break;
        case 'y':
            val = point.Y();
            break;
        case 'z':
            val = point.Z();
            break;
        default:
            return shapes;
        }
        if (std::find(values.begin(), values.end(), val) == values.end()) {
            values.push_back(val);
        }
    }

    std::sort(values.begin(), values.end());

    for (double v : values) {
        std::vector<gp_Pnt> currentLayer;
        for (const auto& point : Points) {
            double val;
            switch (axis) {
            case 'x':
                val = point.X();
                break;
            case 'y':
                val = point.Y();
                break;
            case 'z':
                val = point.Z();
                break;
            default:
                continue;
            }
            if (val == v) {
                currentLayer.push_back(point);
            }
        }
        if(currentLayer.size()<3) continue;
        std::vector<gp_Pnt2d> currentLayer2D;
        for (const auto& point : currentLayer) {
            switch (axis) {
            case 'x':
                currentLayer2D.emplace_back(point.Y(), point.Z());
                break;
            case 'y':
                currentLayer2D.emplace_back(point.X(), point.Z());
                break;
            case 'z':
                currentLayer2D.emplace_back(point.X(), point.Y());
                break;
            default:
                break;
            }
        }

        int n = static_cast<int>(currentLayer2D.size());
        std::vector<gp_Pnt2d> hull;

        if (n < 3) {
            hull = currentLayer2D;
        }
        else {
            int pivot = 0;
            for (int i = 1; i < n; i++) {
                if (currentLayer2D[i].Y() < currentLayer2D[pivot].Y() ||
                    (currentLayer2D[i].Y() == currentLayer2D[pivot].Y() &&
                     currentLayer2D[i].X() < currentLayer2D[pivot].X())) {
                    pivot = i;
                }
            }

            std::vector<gp_Pnt2d> sortedPoints = currentLayer2D;
            std::swap(sortedPoints[0], sortedPoints[pivot]);

            auto comparePoints = [](const gp_Pnt2d& p1, const gp_Pnt2d& p2) {
                if (p1.X() != p2.X()) {
                    return p1.X() < p2.X();
                }
                return p1.Y() < p2.Y();
            };

            auto crossProduct = [](const gp_Pnt2d& O, const gp_Pnt2d& A, const gp_Pnt2d& B) {
                return (A.X() - O.X()) * (B.Y() - O.Y()) - (A.Y() - O.Y()) * (B.X() - O.X());
            };

            std::sort(sortedPoints.begin() + 1, sortedPoints.end(), [&](const gp_Pnt2d& p1, const gp_Pnt2d& p2) {
                double cp = crossProduct(sortedPoints[0], p1, p2);
                if (cp == 0) {
                    return (p1.X() - sortedPoints[0].X()) * (p1.X() - sortedPoints[0].X()) +
                           (p1.Y() - sortedPoints[0].Y()) * (p1.Y() - sortedPoints[0].Y()) <
                           (p2.X() - sortedPoints[0].X()) * (p2.X() - sortedPoints[0].X()) +
                           (p2.Y() - sortedPoints[0].Y()) * (p2.Y() - sortedPoints[0].Y());
                }
                return cp > 0;
            });

            hull.push_back(sortedPoints[0]);
            hull.push_back(sortedPoints[1]);
            for (int i = 2; i < n; i++) {
                while (hull.size() >= 2 && crossProduct(hull[hull.size() - 2], hull[hull.size() - 1], sortedPoints[i]) <= 0) {
                    hull.pop_back();
                }
                hull.push_back(sortedPoints[i]);
            }
        }

        BRepBuilderAPI_MakeWire wireMaker;
        for (size_t i = 0; i < hull.size(); i++) {
            size_t nextIndex = (i + 1) % hull.size();
            gp_Pnt p1, p2;
            switch (axis) {
            case 'x':
                p1 = gp_Pnt(v, hull[i].X(), hull[i].Y());
                p2 = gp_Pnt(v, hull[nextIndex].X(), hull[nextIndex].Y());
                break;
            case 'y':
                p1 = gp_Pnt(hull[i].X(), v, hull[i].Y());
                p2 = gp_Pnt(hull[nextIndex].X(), v, hull[nextIndex].Y());
                break;
            case 'z':
                p1 = gp_Pnt(hull[i].X(), hull[i].Y(), v);
                p2 = gp_Pnt(hull[nextIndex].X(), hull[nextIndex].Y(), v);
                break;
            default:
                break;
            }
            BRepBuilderAPI_MakeEdge edgeMaker(p1, p2);

            if (edgeMaker.IsDone()) {
                wireMaker.Add(edgeMaker.Edge());
            }
        }

        TopoDS_Wire wire = wireMaker.Wire();

        Handle(AIS_Shape) aisWire = new AIS_Shape(wire);
        Handle(Prs3d_Drawer) drawer = aisWire->Attributes();

        drawer->SetWireAspect(new Prs3d_LineAspect(myColor, Aspect_TOL_SOLID, myWidth));
        shapes.push_back(aisWire);
    }
    return shapes;
}

Face::Face(){}

Handle(AIS_Shape) Face::addFace(TopoDS_Wire wire){
    if(wire.Closed()){
        BRepBuilderAPI_MakeFace faceMaker(wire);
        if (faceMaker.IsDone()){
            TopoDS_Face face = faceMaker.Face();
            Handle(AIS_Shape) aisFace = new AIS_Shape(face);
            aisFace->SetColor(myColor);
            aisFace->SetTransparency(myTransparency);

            return aisFace;
        }
    }
    return nullptr;
}

Handle(AIS_Shape) Face::stitchFace(QVector<Handle(AIS_Shape)> selectedShapes){
    BRepBuilderAPI_Sewing sewing(1.0e-1);
    for (auto it = selectedShapes.begin(); it != selectedShapes.end(); ++it){
        const TopoDS_Shape& shape = (*it)->Shape();
        if(shape.ShapeType() == TopAbs_FACE || shape.ShapeType() == TopAbs_COMPOUND)
            sewing.Add(shape);
    }

    sewing.Perform();
    if (sewing.SewedShape().IsNull()) {
        qDebug() << "shell failed!";
        return nullptr;
    }
    TopoDS_Shape sewedShape = sewing.SewedShape();
    if (sewedShape.ShapeType() != TopAbs_SHELL) {
        qDebug() << "Sewing failed to produce a valid Shell!";
        return nullptr;
    }

    TopoDS_Shell shell = TopoDS::Shell(sewedShape);

    BRepBuilderAPI_MakeSolid solidMaker(shell);
    solidMaker.Build();
    if (!solidMaker.IsDone()) {
        qDebug() << "solid failed!";
        return nullptr;
    }
    TopoDS_Solid solid = solidMaker.Solid();
    solid.Reverse();
    Handle(AIS_Shape) aisSolid = new AIS_Shape(solid);

    aisSolid->SetColor(myColor);
    aisSolid->SetTransparency(myTransparency);
    return aisSolid;

}
double Face::calculateVolume(void){
    myContext->InitSelected();

    Handle(AIS_InteractiveObject) selectedObject = myContext->SelectedInteractive();
    Handle(AIS_Shape) selectedShape = Handle(AIS_Shape)::DownCast(selectedObject);

    if (!selectedShape.IsNull()) {
        const TopoDS_Shape& shape = selectedShape->Shape();
        if(shape.ShapeType() == TopAbs_SOLID){
            GProp_GProps props;
            TopoDS_Solid solid = TopoDS::Solid(shape);
            BRepGProp::VolumeProperties(solid, props);
            return props.Mass();
        }
        return 0;
    }
    return 0;
}

double Face::calculateArea(void){
    myContext->InitSelected();

    Handle(AIS_InteractiveObject) selectedObject = myContext->SelectedInteractive();
    Handle(AIS_Shape) selectedShape = Handle(AIS_Shape)::DownCast(selectedObject);

    if (!selectedShape.IsNull()) {
        const TopoDS_Shape& shape = selectedShape->Shape();
        GProp_GProps props;
        BRepGProp::SurfaceProperties(shape, props);
        return props.Mass();
    }
    return 0;
}

