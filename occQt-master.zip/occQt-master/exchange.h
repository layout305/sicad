#ifndef EXCHANGE_H
#define EXCHANGE_H

#include <QWidget>
#include <QFile>
#include <QDebug>

#include <gp_Pnt.hxx>

class exchange : public QWidget
{
public:
    exchange(QWidget* parent);

    QVector<gp_Pnt> readPointCloudFromFile(const QString& filePath);
};

#endif // EXCHANGE_H
