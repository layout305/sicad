/*
*    Copyright (c) 2018 Shing Liu All Rights Reserved.
*
*           File : occQt.h
*         Author : Shing Liu(eryar@163.com)
*           Date : 2018-01-08 20:00
*        Version : OpenCASCADE7.2.0 & Qt5.7.1
*
*    Description : OpenCASCADE in Qt.
*/

#ifndef OCCQT_H
#define OCCQT_H

#include "ui_occQt.h"
#include "SARibbon.h"
#include "exchange.h"
#include "pointcloud.h"
#include "paint.h"
#include "commands.h"
#include <AIS_InteractiveContext.hxx>
#include <AIS_Shape.hxx>

#include <QFileDialog>
#include <QToolBar>
#include <QTimer>
#include <QTreeView>
#include <QMessageBox>
#include <QDockWidget>
#include <gp_Circ.hxx>
#include <gp_Elips.hxx>
#include <gp_Pln.hxx>
#include <gp_Lin2d.hxx>
#include <QDockWidget>
#include <QLineEdit>
#include <QLabel>
#include <QFormLayout>
#include <QWidget>

#include <Geom_ConicalSurface.hxx>
#include <Geom_ToroidalSurface.hxx>
#include <Geom_CylindricalSurface.hxx>

#include <GCE2d_MakeSegment.hxx>

#include <TopoDS.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TColgp_Array1OfPnt2d.hxx>

#include <BRepLib.hxx>
#include <BRepBuilderAPI_MakeVertex.hxx>
#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepBuilderAPI_MakeWire.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepBuilderAPI_Transform.hxx>
#include <BRepBuilderAPI_MakePolygon.hxx>
#include <BRepPrimAPI_MakeBox.hxx>
#include <BRepPrimAPI_MakeCone.hxx>
#include <BRepPrimAPI_MakeSphere.hxx>
#include <BRepPrimAPI_MakeCylinder.hxx>
#include <BRepPrimAPI_MakeTorus.hxx>
#include <BRepPrimAPI_MakePrism.hxx>
#include <BRepPrimAPI_MakeRevol.hxx>
#include <BRepFilletAPI_MakeFillet.hxx>
#include <BRepFilletAPI_MakeChamfer.hxx>
#include <BRepOffsetAPI_MakePipe.hxx>
#include <BRepOffsetAPI_ThruSections.hxx>
#include <BRepAlgoAPI_Cut.hxx>
#include <BRepAlgoAPI_Fuse.hxx>
#include <BRepAlgoAPI_Common.hxx>

class OccView;

//! Qt main window which include OpenCASCADE for its central widget.
class occQt : public SARibbonMainWindow
{
    Q_OBJECT

public:
    //! constructor/destructor.
    occQt(QWidget *parent = nullptr);
    ~occQt();
private slots:
    void makeBox(void);
protected:
    void FileInit(SARibbonBar* bar);
    void MainInit(SARibbonBar* bar);
    void PaintInit(SARibbonBar* bar);
    void MethodInit(SARibbonBar* bar);
    void pointDockWidget(SARibbonPannel* pannel7);
    void lineDockWidget(SARibbonPannel* pannel7);
    void continuousFinish(SARibbonPannel* pannel7);
    void manipulatorFinish(SARibbonPannel* pannel7);

private:
    Ui::occQtClass ui;

    // wrapped the widget for occ.
    OccView* myOccView;

    paint* mypaint;
    Point* myPoint;
    Line* myLine;
    Face* myFace;
    pointCloud* myPointCloud;
    QUndoStack* undoStack;
    bool visible = false;
    QLabel* coordLabel;
    exchange* fileOperate;
};

#endif // OCCQT_H
