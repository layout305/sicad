#ifndef PAINT_H
#define PAINT_H

#include <QWidget>
#include <QDebug>
#include <QColor>
#include <QColorDialog>
#include <QAction>
#include <QDockWidget>

#include <AIS_Point.hxx>
#include <AIS_Shape.hxx>
#include <AIS_InteractiveContext.hxx>
#include <AIS_Manipulator.hxx>
#include <AIS_InteractiveContext.hxx>

#include <Quantity_Color.hxx>
#include <Geom_Point.hxx>
#include <BRepBuilderAPI_MakeVertex.hxx>
#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepBuilderAPI_MakeWire.hxx>
#include <BRepPrimAPI_MakeBox.hxx>
#include <BRepOffsetAPI_ThruSections.hxx>
#include <BRepBuilderAPI.hxx>
#include <BRepBuilderAPI_Sewing.hxx>
#include <BRepBuilderAPI_MakeSolid.hxx>
#include <BRepGProp.hxx>
#include <BRepMesh_IncrementalMesh.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepBuilderAPI_Transform.hxx>
#include <BRepCheck_Analyzer.hxx>


#include <gp_Pnt.hxx>
#include <Graphic3d_AspectMarker3d.hxx>
#include <TopExp_Explorer.hxx>
#include <GProp_GProps.hxx>

#include <Quantity_Color.hxx>
#include <Prs3d_PointAspect.hxx>
#include <Prs3d_LineAspect.hxx>

#include <TopAbs_Orientation.hxx>
#include <TopoDS_Shape.hxx>
#include <TopoDS_Vertex.hxx>
#include <TopoDS_Wire.hxx>
#include <TopoDS.hxx>
static Quantity_NameOfColor myColor;

static double myWidth;

static double myTransparency;

static Handle(AIS_InteractiveContext) myContext;

static Handle(AIS_Manipulator) aManipulator;

class paint :public QWidget
{
public:
    paint(QWidget* parent, Handle(AIS_InteractiveContext) Context, Handle(AIS_Manipulator) Manipulator);
    //void Line(void);
    //void Face(void);
    void setColor(void);
    void setWidth(double width);
    void setTransparency(double transparency);

protected:
    Quantity_NameOfColor FindClosestColor(const Quantity_Color& color);
};

class Point
{
public:
    Point();
    Handle(AIS_Shape) addPoint(gp_Pnt point);
    // It is shared, so it is only written in the point class and will be taken out separately later
    QVector<Handle(AIS_Shape)> deletePoint(void);
    QVector<Handle(AIS_Shape)> movingPoint(gp_Pnt point);
    void drawTempPoint(gp_Pnt point);
    // It is shared, so it is only written in the point class and will be taken out separately later
    bool Manipulator(void);
    // It is shared, so it is only written in the point class and will be taken out separately later
    Handle(AIS_Shape) reDrawPoint(Handle(AIS_Shape) selectedShape);
private:
    Handle(AIS_Shape) tempPoint = nullptr;
};

class Line{
public:
    Line(void);
    Handle(AIS_Shape) addLine(gp_Pnt firstPoint, gp_Pnt SecondPoint);
    Handle(AIS_Shape) makeWire(QVector<Handle(AIS_Shape)> Lines);
    Handle(AIS_Shape) makeLofting(void);
    Handle(AIS_Shape) wireToFace(Handle(AIS_Shape) selectedShape);
    QVector<gp_Pnt> extractVertexCoordinates(const QVector<Handle(AIS_Shape)>& shapes);
    QVector<Handle(AIS_Shape)> convexHull(QVector<gp_Pnt> Points, char coordinate);
    //Handle(AIS_Shape) addTempLine(gp_Pnt firstPoint, gp_Pnt SecondPoint);
};

class Face{
public:
    Face(void);
    Handle(AIS_Shape) addFace(TopoDS_Wire wire);
    Handle(AIS_Shape) stitchFace(QVector<Handle(AIS_Shape)> selectedShapes);
    double calculateVolume(void);
    double calculateArea(void);
};
#endif // PAINT_H
