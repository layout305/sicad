#ifndef POINTCLOUD_H
#define POINTCLOUD_H

#include <QWidget>
#include <QDebug>

#include <AIS_InteractiveContext.hxx>

#include <pcl/io/pcd_io.h>
#include <pcl/io/ply_io.h>

#include <pcl/surface/poisson.h>
#include <pcl/surface/gp3.h>
#include <pcl/surface/concave_hull.h>
#include <pcl/surface/convex_hull.h>

#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <pcl/filters/passthrough.h>

#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/kdtree/kdtree.h>

#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>

#include <pcl/features/normal_3d.h>

#include <pcl/point_types.h>


class pointCloud : public QWidget
{
public:
    pointCloud(QWidget* parent, Handle(AIS_InteractiveContext) Context);
public:
    // filtering
    pcl::PointCloud<pcl::PointXYZ>::Ptr voxelGrid(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud);
    pcl::PointCloud<pcl::PointXYZ>::Ptr statisticalOutlierRemoval(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud);
    pcl::PointCloud<pcl::PointXYZ>::Ptr radiusOutlierRemoval(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud);

    // segmentation
    void planeSegmentation(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud);
    void clusterSegmentation(void);

    // rebuild
    void greedyTriangulation(void);
    void poissonRebuild(void);
private:
    Handle(AIS_InteractiveContext) myContext;
};


#endif // POINTCLOUD_H

