#include "commands.h"
#include <TopoDS.hxx>
#include <BRep_Tool.hxx>
MoveCommand::MoveCommand(Handle(AIS_Shape) oldShape, Handle(AIS_Shape) newShape, Handle(AIS_InteractiveContext) Context, QUndoCommand *parent)
    : QUndoCommand(parent),
      myOldShape(oldShape),
      myNewShape(newShape),
      myContext(Context)
{
}

void MoveCommand::undo()
{
    if (!myContext.IsNull() && !myNewShape.IsNull() && !myOldShape.IsNull()) {
        myContext->Remove(myNewShape,Standard_True);
        myContext->Display(myOldShape,Standard_True);
    }
}

void MoveCommand::redo()
{
    if (!myContext.IsNull() && !myNewShape.IsNull() && !myOldShape.IsNull()) {
        myContext->Remove(myOldShape,Standard_True);
        myContext->Display(myNewShape,Standard_True);
    }
}


DeleteCommand::DeleteCommand(QVector<Handle(AIS_Shape)> shapes, Handle(AIS_InteractiveContext) Context, QUndoCommand *parent)
    : QUndoCommand(parent), myShapes(shapes), myContext(Context)
{
}

void DeleteCommand::undo()
{
    if (!myContext.IsNull() && !myShapes.empty()) {
        for(auto shape : myShapes)
            myContext->Display(shape, Standard_True);
    }
}

void DeleteCommand::redo()
{
    if (!myContext.IsNull() && !myShapes.empty()) {
        for (auto shape : myShapes) {
            myContext->Remove(shape, Standard_True);
        }
    }
}


AddCommand::AddCommand(Handle(AIS_Shape) Shape, Handle(AIS_InteractiveContext) Context, QUndoCommand *parent)
    : QUndoCommand(parent), myShape(Shape),myContext(Context)
{
}

void AddCommand::undo()
{

    if (!myContext.IsNull() && !myShape.IsNull()) {
        myContext->Remove(myShape, Standard_True);
    }
}

void AddCommand::redo()
{

    if (!myContext.IsNull() && !myShape.IsNull()) {
        myContext->Display(myShape, Standard_True);
    }
}
