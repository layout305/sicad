#include "exchange.h"

exchange::exchange(QWidget* parent )
    : QWidget(parent)
{

}

QVector<gp_Pnt> exchange::readPointCloudFromFile(const QString& filePath){

    QVector<gp_Pnt> pointCloudData;

    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "open failed:" << filePath;
        return pointCloudData;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList values = line.split(QRegExp("\\s+"), Qt::SkipEmptyParts);

        if (values.size() == 3) {
            bool okX, okY, okZ;
            double x = values[0].toDouble(&okX);
            double y = values[1].toDouble(&okY);
            double z = values[2].toDouble(&okZ);

            if (okX && okY && okZ)
                pointCloudData.push_back(gp_Pnt(x,y,z));

        }
    }

    file.close();
    return pointCloudData;
}
