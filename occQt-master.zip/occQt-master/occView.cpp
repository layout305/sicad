/*
*    Copyright (c) 2018 Shing Liu All Rights Reserved.
*
*           File : OccView.cpp
*         Author : Shing Liu(eryar@163.com)
*           Date : 2018-01-08 21:00
*        Version : OpenCASCADE7.2.0 & Qt5.7.1
*
*    Description : Qt widget for OpenCASCADE viewer.
*/

#include "occView.h"

static Handle(Graphic3d_GraphicDriver)& GetGraphicDriver()
{
  static Handle(Graphic3d_GraphicDriver) aGraphicDriver;
  return aGraphicDriver;
}

OccView::OccView(QWidget* parent )
    : QWidget(parent),
    myXmin(0),
    myYmin(0),
    myXmax(0),
    myYmax(0),    
    myCurrentMode(CurAction3d_DynamicRotation),
    myDegenerateModeIsOn(Standard_True),
    myRectBand(NULL)
{
    // No Background
    setBackgroundRole( QPalette::NoRole );

    // set focus policy to threat QContextMenuEvent from keyboard  
    setFocusPolicy(Qt::StrongFocus);
    setAttribute(Qt::WA_PaintOnScreen);
    setAttribute(Qt::WA_NoSystemBackground);

    // Enable the mouse tracking, by default the mouse tracking is disabled.
    setMouseTracking( true );

    init();

    undoStack = new QUndoStack(this);

    aManipulator = new AIS_Manipulator();
    aManipulator->EnableMode(AIS_ManipulatorMode::AIS_MM_Translation);
    aManipulator->EnableMode(AIS_ManipulatorMode::AIS_MM_Rotation);
    aManipulator->EnableMode(AIS_ManipulatorMode::AIS_MM_Scaling);
    aManipulator->SetModeActivationOnDetection(Standard_True);

}

void OccView::init()
{
    // Create Aspect_DisplayConnection
    Handle(Aspect_DisplayConnection) aDisplayConnection =
            new Aspect_DisplayConnection();

    // Get graphic driver if it exists, otherwise initialise it
    if (GetGraphicDriver().IsNull())
    {
        GetGraphicDriver() = new OpenGl_GraphicDriver(aDisplayConnection);
    }

    // Get window handle. This returns something suitable for all platforms.
    WId window_handle = (WId) winId();

    // Create appropriate window for platform
    #ifdef WNT
        Handle(WNT_Window) wind = new WNT_Window((Aspect_Handle) window_handle);
    #elif defined(__APPLE__) && !defined(MACOSX_USE_GLX)
        Handle(Cocoa_Window) wind = new Cocoa_Window((NSView *) window_handle);
    #else
        Handle(Xw_Window) wind = new Xw_Window(aDisplayConnection, (Window) window_handle);
    #endif

    // Create V3dViewer and V3d_View
    myViewer = new V3d_Viewer(GetGraphicDriver());

    myView = myViewer->CreateView();

    myView->SetWindow(wind);
    if (!wind->IsMapped()) wind->Map();

    // Create AISInteractiveContext
    myContext = new AIS_InteractiveContext(myViewer);

    // Set up lights etc
    myViewer->SetDefaultLights();
    myViewer->SetLightOn();

    myView->SetBackgroundColor(Quantity_NOC_BLACK);
    myView->MustBeResized();
    myView->TriedronDisplay(Aspect_TOTP_LEFT_LOWER, Quantity_NOC_GOLD, 0.08, V3d_ZBUFFER);

    myContext->SetDisplayMode(AIS_Shaded, Standard_True);
    myView->SetBgGradientColors(Quantity_NOC_LIGHTSKYBLUE, Quantity_NOC_LIGHTSKYBLUE4, Aspect_GFM_VER);
    myViewer->ActivateGrid(Aspect_GT_Rectangular, Aspect_GDM_Lines);

    Handle(AIS_ViewCube) H_AisViewCube = new AIS_ViewCube();
    H_AisViewCube->SetBoxColor(Quantity_NOC_WHITE);
    H_AisViewCube->SetTransparency(0.5);
    H_AisViewCube->SetTextColor(Quantity_Color(Quantity_NOC_BLACK));
    H_AisViewCube->SetFontHeight(18);

    const Handle(Prs3d_Drawer)& myDrawer = H_AisViewCube->Attributes();
    myDrawer->SetupOwnFaceBoundaryAspect();
    myDrawer->SetFaceBoundaryDraw(true);
    myDrawer->FaceBoundaryAspect()->SetColor(Quantity_NameOfColor::Quantity_NOC_LIGHTSKYBLUE);
    myDrawer->FaceBoundaryAspect()->SetWidth(2.0);

    myDrawer->SetDatumAspect(new Prs3d_DatumAspect());
    const Handle_Prs3d_DatumAspect& datumAspect = H_AisViewCube->Attributes()->DatumAspect();

    datumAspect->ShadingAspect(Prs3d_DP_XAxis)->SetColor(Quantity_NOC_RED);
    datumAspect->ShadingAspect(Prs3d_DP_YAxis)->SetColor(Quantity_NOC_GREEN);
    datumAspect->ShadingAspect(Prs3d_DP_ZAxis)->SetColor(Quantity_NOC_BLUE);
    datumAspect->TextAspect(Prs3d_DP_XAxis)->SetColor(Quantity_NOC_RED);
    datumAspect->TextAspect(Prs3d_DP_YAxis)->SetColor(Quantity_NOC_GREEN);
    datumAspect->TextAspect(Prs3d_DP_ZAxis)->SetColor(Quantity_NOC_BLUE);

    H_AisViewCube->SetTransformPersistence(
        new Graphic3d_TransformPers(
            Graphic3d_TMF_TriedronPers,
            Aspect_TOTP_RIGHT_UPPER,
            Graphic3d_Vec2i(100, 100)));
    myContext->Display(H_AisViewCube, Standard_True);
}

const Handle(AIS_InteractiveContext)& OccView::getContext() const
{
    return myContext;
}

QUndoStack* OccView::getUndoStack(){
    return undoStack;
}

Handle(AIS_Manipulator) OccView::getManipulator(){
    return aManipulator;
}

void OccView::clearnLines(void){
    linesForWire.clear();
}

QVector<Handle(AIS_Shape)> OccView::getLinesForWire(void){
    return linesForWire;
}

bool OccView::makeFace(void){
    myContext->InitSelected();
    Handle(AIS_InteractiveObject) selectedObject = myContext->SelectedInteractive();
    Handle(AIS_Shape) selectedShape = Handle(AIS_Shape)::DownCast(selectedObject);
    if(!selectedShape.IsNull()){
        QVector<Handle(AIS_Shape)> Shapes;
        Shapes.push_back(selectedShape);
        undoStack->push(new DeleteCommand(Shapes, myContext));
        class Line* face = new class Line();
        Handle(AIS_Shape) myFace = face->wireToFace(selectedShape);
        if(!myFace.IsNull()){
            undoStack->push(new AddCommand(myFace, myContext));
            return true;
        }
    }

    return false;
}

void OccView::makeSolid(void){
    QVector<Handle(AIS_Shape)> myShapes;
    myContext->InitSelected();

    while (myContext->MoreSelected()) {
        Handle(AIS_InteractiveObject) selectedObject = myContext->SelectedInteractive();
        Handle(AIS_Shape) selectedShape = Handle(AIS_Shape)::DownCast(selectedObject);
        if (!selectedShape.IsNull()) {
            myShapes.push_back(selectedShape);
        }
        myContext->NextSelected();
    }
    undoStack->push(new DeleteCommand(myShapes, myContext));

    class Face* face = new class Face();
    Handle(AIS_Shape) mySolid = face->stitchFace(myShapes);
    if(!mySolid.IsNull()){

        undoStack->push(new AddCommand(mySolid, myContext));
    }
    else
        QMessageBox::warning(this, tr("Woring"),tr("Solid construction failed."), QMessageBox::Abort);
}

void OccView::redraw()
{
    myView->Redraw();
}

void OccView::closeWire(void){
    if(pointsForLine.size() > 1){
        class Line *myLine = new class Line();
        Handle(AIS_Shape) shape = myLine->addLine(pointsForLine.front(), pointsForLine.back());
        if(!shape.IsNull()){
            QUndoCommand *addCommand = new AddCommand(shape, myContext);
            undoStack->push(addCommand);
            linesForWire.push_back(shape);
        }
    }
}

void OccView::splitManipulator(void)
{

    aManipulator->DeactivateCurrentMode();
    aManipulator->Detach();

    myContext->InitSelected();

    Handle(AIS_InteractiveObject) selectedObject = myContext->SelectedInteractive();
    Handle(AIS_Shape) selectedShape = Handle(AIS_Shape)::DownCast(selectedObject);
    QVector<Handle(AIS_Shape)> shapes;
    shapes.push_back(selectedShape);
    undoStack->push(new DeleteCommand(shapes, myContext));

    class Point *myPoint = new class Point();

    Handle(AIS_Shape) aisShape = myPoint->reDrawPoint(selectedShape);
    if(!aisShape.IsNull()){
        //qDebug()<<"new shape finish!";
        undoStack->push(new AddCommand(aisShape, myContext));
    }
    myView->Redraw();

}

void OccView::getPoints(char coordinate){
    QVector<Handle(AIS_Shape)> myPoints;
    myContext->InitSelected();

    while (myContext->MoreSelected()) {
        Handle(AIS_InteractiveObject) selectedObject = myContext->SelectedInteractive();
        Handle(AIS_Shape) selectedShape = Handle(AIS_Shape)::DownCast(selectedObject);
        if (!selectedShape.IsNull()) {
            myPoints.push_back(selectedShape);
        }
        myContext->NextSelected();
    }
    undoStack->push(new DeleteCommand(myPoints, myContext));
    class Line* points = new class Line();
    QVector<gp_Pnt> coordinates = points->extractVertexCoordinates(myPoints);
    QVector<Handle(AIS_Shape)> myWires;
    if(coordinates.size() != 0){
        myWires = points->convexHull(coordinates, coordinate);
    }
    else{
        QMessageBox::warning(this, tr("Woring"),tr("Vertex not obtained, please select again."), QMessageBox::Abort);
        return;
    }
    if(myWires.size() != 0){
        for (const auto& wire : myWires){
            undoStack->push(new AddCommand(wire, myContext));
        }
    }
    else{
        QMessageBox::warning(this, tr("Woring"),tr("Wireframe generation failed."), QMessageBox::Abort);
        return;
    }

}

/*!
Get paint engine for the OpenGL viewer. [ virtual public ]
*/
QPaintEngine* OccView::paintEngine() const
{
    return 0;
}

void OccView::paintEvent( QPaintEvent* /*theEvent*/ )
{
    myView->Redraw();
}

void OccView::resizeEvent( QResizeEvent* /*theEvent*/ )
{
    if( !myView.IsNull() )
    {
        myView->MustBeResized();
    }
}

void OccView::fitAll( void )
{
    myView->FitAll();
    myView->ZFitAll();
    myView->Redraw();
}

void OccView::reset( void )
{
    myView->Reset();
}

void OccView::pan( void )
{
    myCurrentMode = CurAction3d_DynamicPanning;
}

void OccView::zoom( void )
{
    myCurrentMode = CurAction3d_DynamicZooming;
}

void OccView::rotate( void )
{
    myCurrentMode = CurAction3d_DynamicRotation;
}

void OccView::Point(void){
    myCurrentMode = CurAction3d_Point;
}

void OccView::Line(void){
    pointsForLine.clear();
    myCurrentMode = CurAction3d_Line;
}

void OccView::Continuous(void){
    pointsForLine.clear();
    myCurrentMode = CurAction3d_Continuous;
}

void OccView::Moving(void){
    myCurrentMode = CurAction3d_Moving;
}

void OccView::grid(void){
    if(gridOpened){
        myViewer->DeactivateGrid();
        gridOpened = false;
       myView->Redraw();
    }
    else{
        myViewer->ActivateGrid(Aspect_GT_Rectangular, Aspect_GDM_Lines);
        gridOpened = true;
        myView->Redraw();
    }
}


void OccView::DirectionX_Y(void){
    myView->SetProj(V3d_Zpos);
    myView->SetTwist(0.0);
    myView->FitAll();
}
void OccView::DirectionX_Z(void){
    myView->SetProj(V3d_Ypos);
    myView->SetTwist(0.0);
    myView->FitAll();
}
void OccView::DirectionY_Z(void){
    myView->SetProj(V3d_Xpos);
    myView->SetTwist(0.0);
    myView->FitAll();
}


void OccView::mousePressEvent( QMouseEvent* theEvent )
{
    if (theEvent->button() == Qt::LeftButton)
    {
        if(myCurrentMode == CurAction3d_Point){
            QPoint screenPos = theEvent->pos();
            Standard_Real x, y, z;
            myView->Convert(screenPos.x(), screenPos.y(), x, y, z);
            gp_Pnt point(x, y, 0.0);
            class Point *myPoint = new class Point();
            Handle(AIS_Shape) shape = myPoint->addPoint(point);
            QUndoCommand *addCommand = new AddCommand(shape, myContext);
            undoStack->push(addCommand);
        }
        else if(myCurrentMode == CurAction3d_Line){
            QPoint screenPos = theEvent->pos();
            Standard_Real x, y, z;
            myView->Convert(screenPos.x(), screenPos.y(), x, y, z);
            gp_Pnt point(x, y, 0.0);
            if(pointsForLine.size() == 0)
                pointsForLine.push_back(point);
            else{
                pointsForLine.push_back(point);
                class Line *myLine = new class Line();
                Handle(AIS_Shape) shape = myLine->addLine(pointsForLine.front(), pointsForLine.back());
                if(!shape.IsNull()){
                    QUndoCommand *addCommand = new AddCommand(shape, myContext);
                    undoStack->push(addCommand);
                }
                pointsForLine.clear();
            }

        }
        else if(myCurrentMode == CurAction3d_Continuous){
            QPoint screenPos = theEvent->pos();
            Standard_Real x, y, z;
            myView->Convert(screenPos.x(), screenPos.y(), x, y, z);
            gp_Pnt point(x, y, 0.0);
            if(pointsForLine.size() == 0)
                pointsForLine.push_back(point);
            else{
                pointsForLine.push_back(point);
                class Line *myLine = new class Line();
                Handle(AIS_Shape) shape = myLine->addLine(pointsForLine.at(pointsForLine.size() - 2), pointsForLine.back());
                if(!shape.IsNull()){
                    QUndoCommand *addCommand = new AddCommand(shape, myContext);
                    undoStack->push(addCommand);
                    linesForWire.push_back(shape);
                }
            }
        }

        else if(aManipulator->HasActiveMode())
        {
            aManipulator->StartTransform(theEvent->x(), theEvent->y(), myView);
        }
        else
            onLButtonDown((theEvent->buttons() | theEvent->modifiers()), theEvent->pos());

    }
    else if (theEvent->button() == Qt::MidButton)
    {
        onMButtonDown((theEvent->buttons() | theEvent->modifiers()), theEvent->pos());
    }
    else if (theEvent->button() == Qt::RightButton)
    {
        if(myCurrentMode == CurAction3d_Continuous){
            myContext->Remove(tempLine,Standard_True);
            myView->Redraw();
            pan();
        }
        else
            onRButtonDown((theEvent->buttons() | theEvent->modifiers()), theEvent->pos());
    }
}

void OccView::mouseReleaseEvent( QMouseEvent* theEvent )
{
    if (theEvent->button() == Qt::LeftButton)
    {
//        if(myCurrentMode == CurAction3d_Moving){
//            QPoint screenPos = theEvent->pos();
//            Standard_Real x, y, z;
//            myView->Convert(screenPos.x(), screenPos.y(), x, y, z);
//            gp_Pnt point(x, y, 0.0);
//            class Point *myPoint = new class Point();
//            QVector<Handle(AIS_Shape)> shapes = myPoint->movingPoint(point);
//            QUndoCommand *moveCommand = new MoveCommand(shapes.front(),shapes.back(), myContext);
//            undoStack->push(moveCommand);
//            myCurrentMode = CurAction3d_DynamicPanning;

//        }
//        else
        aManipulator->StopTransform(Standard_True);

        onLButtonUp(theEvent->buttons() | theEvent->modifiers(), theEvent->pos());
    }
    else if (theEvent->button() == Qt::MidButton)
    {
        onMButtonUp(theEvent->buttons() | theEvent->modifiers(), theEvent->pos());
    }
    else if (theEvent->button() == Qt::RightButton)
    {
        onRButtonUp(theEvent->buttons() | theEvent->modifiers(), theEvent->pos());
    }
}

void OccView::mouseMoveEvent( QMouseEvent * theEvent )
{
    if((theEvent->buttons() & Qt::LeftButton) && aManipulator->HasActiveMode()){
        aManipulator->Transform(theEvent->x(), theEvent->y(), myView);
        myView->Redraw();
    }
    else if(myCurrentMode == CurAction3d_Line || myCurrentMode == CurAction3d_Continuous){
        myContext->Remove(tempLine, Standard_True);

        if(pointsForLine.size() > 0){
            QPoint screenPos = theEvent->pos();
            Standard_Real x, y, z;
            myView->Convert(screenPos.x(), screenPos.y(), x, y, z);
            gp_Pnt point(x, y, 0.0);
            class Line *myLine = new class Line();
            tempLine = myLine->addLine(pointsForLine.back(), point);
            if(!tempLine.IsNull()){
                myContext->Display(tempLine, Standard_True);
            }
        }
    }

    else
        onMouseMove(theEvent->buttons(), theEvent->pos());

    QPoint screenPos = theEvent->pos();
    Standard_Real x, y, z;
    myView->Convert(screenPos.x(), screenPos.y(), x, y, z);
    emit coordinateChanged(x,y);
}

void OccView::wheelEvent( QWheelEvent * theEvent )
{
    onMouseWheel(theEvent->buttons(), theEvent->delta(), theEvent->pos());
}

void OccView::onLButtonDown( const int /*theFlags*/, const QPoint thePoint )
{
    // Save the current mouse coordinate in min.
    myXmin = thePoint.x();
    myYmin = thePoint.y();
    myXmax = thePoint.x();
    myYmax = thePoint.y();

}

void OccView::onMButtonDown( const int /*theFlags*/, const QPoint thePoint )
{
    // Save the current mouse coordinate in min.
    myXmin = thePoint.x();
    myYmin = thePoint.y();
    myXmax = thePoint.x();
    myYmax = thePoint.y();

    if (myCurrentMode == CurAction3d_DynamicRotation)
    {
        myView->StartRotation(thePoint.x(), thePoint.y());
    }
}

void OccView::onRButtonDown( const int /*theFlags*/, const QPoint /*thePoint*/ )
{

}

void OccView::onMouseWheel( const int /*theFlags*/, const int theDelta, const QPoint thePoint )
{
    Standard_Integer aFactor = 16;

    Standard_Integer aX = thePoint.x();
    Standard_Integer aY = thePoint.y();

    if (theDelta > 0)
    {
        aX += aFactor;
        aY += aFactor;
    }
    else
    {
        aX -= aFactor;
        aY -= aFactor;
    }

    myView->Zoom(thePoint.x(), thePoint.y(), aX, aY);
}

void OccView::addItemInPopup( QMenu* /*theMenu*/ )
{
}

void OccView::enterEvent(QEvent *event)
{
    setCursor(Qt::CrossCursor);
    QWidget::enterEvent(event);
}

void OccView::leaveEvent(QEvent *event)
{
    setCursor(Qt::ArrowCursor);
    QWidget::leaveEvent(event);
}

void OccView::popup( const int /*x*/, const int /*y*/ )
{
}

void OccView::onLButtonUp( const int theFlags, const QPoint thePoint )
{
    // Hide the QRubberBand
    if (myRectBand)
    {
        myRectBand->hide();
    }

    // Ctrl for multi selection.
    if (thePoint.x() == myXmin && thePoint.y() == myYmin)
    {
        if (theFlags & Qt::ControlModifier)
        {
            multiInputEvent(thePoint.x(), thePoint.y());
        }
        else
        {
            inputEvent(thePoint.x(), thePoint.y());
        }
    }

}

void OccView::onMButtonUp( const int /*theFlags*/, const QPoint thePoint )
{
    if (thePoint.x() == myXmin && thePoint.y() == myYmin)
    {
        panByMiddleButton(thePoint);
    }
}

void OccView::onRButtonUp( const int /*theFlags*/, const QPoint thePoint )
{
    popup(thePoint.x(), thePoint.y());
}

void OccView::onMouseMove( const int theFlags, const QPoint thePoint )
{
    // Draw the rubber band.
    if (theFlags & Qt::LeftButton)
    {

        drawRubberBand(myXmin, myYmin, thePoint.x(), thePoint.y());

        dragEvent(thePoint.x(), thePoint.y());


    }

    // Ctrl for multi selection.
    if (theFlags & Qt::ControlModifier)
    {
        multiMoveEvent(thePoint.x(), thePoint.y());
    }
    else
    {
        moveEvent(thePoint.x(), thePoint.y());
    }

    // Middle button.
    if (theFlags & Qt::MidButton)
    {
        switch (myCurrentMode)
        {
        case CurAction3d_DynamicRotation:
            myView->Rotation(thePoint.x(), thePoint.y());
            break;

        case CurAction3d_DynamicZooming:
            myView->Zoom(myXmin, myYmin, thePoint.x(), thePoint.y());
            break;

        case CurAction3d_DynamicPanning:
            myView->Pan(thePoint.x() - myXmax, myYmax - thePoint.y());
            myXmax = thePoint.x();
            myYmax = thePoint.y();
            break;

        case CurAction3d_Point:
            myView->Pan(thePoint.x() - myXmax, myYmax - thePoint.y());
            myXmax = thePoint.x();
            myYmax = thePoint.y();
            break;
         default:
            break;
        }
    }

}

void OccView::dragEvent( const int x, const int y )
{
    myContext->Select(myXmin, myYmin, x, y, myView, Standard_True);

    emit selectionChanged();
}

void OccView::multiDragEvent( const int x, const int y )
{
    myContext->ShiftSelect(myXmin, myYmin, x, y, myView, Standard_True);

    emit selectionChanged();

}

void OccView::inputEvent( const int x, const int y )
{
    Q_UNUSED(x);
    Q_UNUSED(y);

    myContext->Select(Standard_True);

    emit selectionChanged();
}

void OccView::multiInputEvent( const int x, const int y )
{
    Q_UNUSED(x);
    Q_UNUSED(y);

    myContext->ShiftSelect(Standard_True);

    emit selectionChanged();
}

void OccView::moveEvent( const int x, const int y )
{
    myContext->MoveTo(x, y, myView, Standard_True);
}

void OccView::multiMoveEvent( const int x, const int y )
{
    myContext->MoveTo(x, y, myView, Standard_True);
}

void OccView::drawRubberBand( const int minX, const int minY, const int maxX, const int maxY )
{
    QRect aRect;

    // Set the rectangle correctly.
    (minX < maxX) ? (aRect.setX(minX)) : (aRect.setX(maxX));
    (minY < maxY) ? (aRect.setY(minY)) : (aRect.setY(maxY));

    aRect.setWidth(abs(maxX - minX));
    aRect.setHeight(abs(maxY - minY));

    if (!myRectBand)
    {
        myRectBand = new QRubberBand(QRubberBand::Rectangle, this);

        // setStyle is important, set to windows style will just draw
        // rectangle frame, otherwise will draw a solid rectangle.
        myRectBand->setStyle(QStyleFactory::create("windows"));
    }

    myRectBand->setGeometry(aRect);
    myRectBand->show();
}

void OccView::panByMiddleButton( const QPoint& thePoint )
{
    Standard_Integer aCenterX = 0;
    Standard_Integer aCenterY = 0;

    QSize aSize = size();

    aCenterX = aSize.width() / 2;
    aCenterY = aSize.height() / 2;

    myView->Pan(aCenterX - thePoint.x(), thePoint.y() - aCenterY);
}
