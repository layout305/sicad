#ifndef COMMANDS_H
#define COMMANDS_H

#include <QUndoCommand>
#include "paint.h"
class MoveCommand : public QUndoCommand
{
public:

    MoveCommand(Handle(AIS_Shape) oldShape, Handle(AIS_Shape) newShape, Handle(AIS_InteractiveContext) Context, QUndoCommand *parent = nullptr);
    //~MoveCommand();
    void undo() override;
    void redo() override;

private:

    Handle(AIS_Shape) myOldShape;
    Handle(AIS_Shape) myNewShape;
    Handle(AIS_InteractiveContext) myContext;
};

class DeleteCommand : public QUndoCommand
{
public:
    DeleteCommand(QVector<Handle(AIS_Shape)> shapes, Handle(AIS_InteractiveContext) Context, QUndoCommand *parent = nullptr);
    //~DeleteCommand();
    void undo() override;
    void redo() override;

private:
    QVector<Handle(AIS_Shape)> myShapes;
    Handle(AIS_InteractiveContext) myContext;
};

class AddCommand : public QUndoCommand
{
public:
    AddCommand(Handle(AIS_Shape) Shape, Handle(AIS_InteractiveContext) Context, QUndoCommand *parent = nullptr);
    //~AddCommand();

    void undo() override;
    void redo() override;

private:
    Handle(AIS_Shape) myShape;
    Handle(AIS_InteractiveContext) myContext;
};
#endif // COMMANDS_H
