/*
*    Copyright (c) 2018 Shing Liu All Rights Reserved.
*
*           File : occQt.cpp
*         Author : Shing Liu(eryar@163.com)
*           Date : 2018-01-08 21:00
*        Version : OpenCASCADE7.2.0 & Qt5.7.1
*
*    Description : Qt main window for OpenCASCADE.
*/

#include "occQt.h"
#include "occView.h"

#include <QSlider>
#include <QMenu>
#include <QWidgetAction>
occQt::occQt(QWidget *parent)
    : SARibbonMainWindow(parent)
{
    ui.setupUi(this);
    this->resize(1200,800);
    //this->setFont(StyleHint::System);

    myOccView = new OccView(this);
    setCentralWidget(myOccView);

    mypaint = new paint(this,myOccView->getContext(),myOccView->getManipulator());
    myPoint = new Point();
    myFace = new Face();
    undoStack = myOccView->getUndoStack();
    setWindowTitle("SiCad");
    setWindowIcon(QIcon(":/Resources/Logo.png"));

    SARibbonBar* bar = ribbonBar();
    bar->setRibbonStyle(SARibbonBar::RibbonStyleLooseThreeRow);

    FileInit(bar);
    MainInit(bar);
    PaintInit(bar);
    MethodInit(bar);

    coordLabel = new QLabel("X: 0, Y: 0", this);
    coordLabel->setAlignment(Qt::AlignCenter);
    coordLabel->setMinimumWidth(150);
    statusBar()->addPermanentWidget(coordLabel);

    QTimer::singleShot(0, this, [ this ]() { this->setRibbonTheme(SARibbonTheme::RibbonThemeWindows7); });

    connect(myOccView, &OccView::coordinateChanged, this, [=](Standard_Real x, Standard_Real y){
        coordLabel->setText(QString("X: %1, Y: %2").arg(x).arg(y));
    });

    fileOperate = new exchange(this);
    myPointCloud = new pointCloud(this, myOccView->getContext());
}

occQt::~occQt()
{

}


void occQt::FileInit(SARibbonBar* bar){
    bar->applicationButton()->setText(tr("  File  "));

    QAction* New = new QAction(QIcon(":/Resources/new.png"), "New");
    QAction* Save = new QAction(QIcon(":/Resources/save.png"), "Save");
    QAction* Open = new QAction(QIcon(":/Resources/open.png"), "Open");
    QAction* Script = new QAction(QIcon(":/Resources/script.png"), "Script");

    bar->applicationButton()->addAction(New);
    bar->applicationButton()->addAction(Save);
    bar->applicationButton()->addAction(Open);
    bar->applicationButton()->addAction(Script);

    connect(New,&QAction::triggered,this,[=](){qDebug()  << "do something";});
    connect(Save,&QAction::triggered,this,[=](){undoStack->clear();});
    connect(Open,&QAction::triggered,this,[=](){qDebug()  << "do something";});
    connect(Script,&QAction::triggered,this,[=](){qDebug()  << "do something";});
}
void occQt::MainInit(SARibbonBar* bar){
    SARibbonCategory* categoryMain = bar->addCategoryPage(tr("&Main"));
    categoryMain->setObjectName(("categoryMain"));

    SARibbonPannel* pannel1  = categoryMain->addPannel(tr("Option"));
    SARibbonPannel* pannel2  = categoryMain->addPannel(tr("Menu"));
    SARibbonPannel* pannel3  = categoryMain->addPannel(tr("Addition"));

    QAction* Undo = new QAction(QIcon(":/Resources/undo.png"), tr("Undo"));
    QAction* Redo = new QAction(QIcon(":/Resources/redo.png"), tr("Redo"));
    QAction* Reset = new QAction(QIcon(":/Resources/reset.png"), tr("Reset"));
    QAction* Fitall = new QAction(QIcon(":/Resources/fitall.png"), tr("Fitall"));
    QAction* Pan = new QAction(QIcon(":/Resources/pan.png"), tr("Pan"));
    QAction* Rotate = new QAction(QIcon(":/Resources/rotate.png"), tr("Rotate"));
    QAction* Grid = new QAction(QIcon(":/Resources/grid.png"), tr("Grid"));
    QAction* Import = new QAction(QIcon(":/Resources/import.png"), tr("Import"));
    QMenu* direction = new QMenu("Direction");
    QAction* DirectionX_Y = new QAction(QIcon(":/Resources/direction.png"), tr("Direction(x,y)"));
    QAction* DirectionX_Z = new QAction(QIcon(":/Resources/direction.png"), tr("Direction(x,z)"));
    QAction* DirectionY_Z = new QAction(QIcon(":/Resources/direction.png"), tr("Direction(y,z)"));

    direction->addAction(DirectionX_Y);
    direction->addAction(DirectionX_Z);
    direction->addAction(DirectionY_Z);
    pannel1->addAction(Undo, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel1->addAction(Redo, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel2->addAction(Reset, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel2->addAction(Fitall, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel2->addAction(Pan, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel2->addAction(Rotate, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel2->addAction(Grid, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel2->addMenu(direction,SARibbonPannelItem::RowProportion::Medium);
    pannel3->addAction(Import, QToolButton::InstantPopup, SARibbonPannelItem::Large);


    connect(Undo, &QAction::triggered, undoStack, [=](){
        undoStack->undo();
        myOccView->redraw();
        //qDebug()<<"redraw";
    });
    connect(Redo, &QAction::triggered, undoStack, [=](){
        undoStack->redo();
        myOccView->redraw();
        //qDebug()<<"redraw";
    });
    connect(Reset, SIGNAL(triggered()), myOccView, SLOT(reset()));
    connect(Fitall, SIGNAL(triggered()), myOccView, SLOT(fitAll()));
    connect(Pan, SIGNAL(triggered()), myOccView, SLOT(pan()));
    connect(Rotate, SIGNAL(triggered()), myOccView, SLOT(rotate()));
    connect(Grid, SIGNAL(triggered()), myOccView, SLOT(grid()));
    connect(DirectionX_Y, SIGNAL(triggered()), myOccView, SLOT(DirectionX_Y()));
    connect(DirectionX_Z, SIGNAL(triggered()), myOccView, SLOT(DirectionX_Z()));
    connect(DirectionY_Z, SIGNAL(triggered()), myOccView, SLOT(DirectionY_Z()));
    connect(Import,&QAction::triggered,this,[=](){
        QString fileName = QFileDialog::getOpenFileName(this,"Select text file", "D:", "文本文件 (*.txt);;所有文件 (*)");
        QVector<gp_Pnt> pointCloud = fileOperate->readPointCloudFromFile(fileName);
        if(pointCloud.size() != 0){
            for (auto point = pointCloud.begin(); point != pointCloud.end(); ++point){
                Handle(AIS_Shape) shape = myPoint->addPoint(*point);
                QUndoCommand *addCommand = new AddCommand(shape, myOccView->getContext());
                undoStack->push(addCommand);
            }
        }

    });
}
void occQt::PaintInit(SARibbonBar* bar){
    SARibbonCategory* categoryPaint = bar->addCategoryPage(tr("&Paint"));
    categoryPaint->setObjectName(("categoryTool"));

    SARibbonPannel* pannel4  = categoryPaint->addPannel(tr("Type"));
    SARibbonPannel* pannel5  = categoryPaint->addPannel(tr("Model"));
    SARibbonPannel* pannel6  = categoryPaint->addPannel(tr("Setting"));

    QAction* Point = new QAction(QIcon(":/Resources/point.png"), tr("Point"));
    QAction* Line = new QAction(QIcon(":/Resources/line.png"), tr("Line"));
    QAction* Continuous = new QAction(QIcon(":/Resources/continuous.png"), tr("Continuous"));
    QAction* Face = new QAction(QIcon(":/Resources/face.png"), tr("Face"));
    QAction* Box = new QAction(QIcon(":/Resources/box.png"), tr("Box"));
    QAction* Cone = new QAction(QIcon(":/Resources/cone.png"), tr("Cone"));
    QAction* Sphere = new QAction(QIcon(":/Resources/sphere.png"), tr("Sphere"));
    QAction* Cylinder = new QAction(QIcon(":/Resources/cylinder.png"), tr("Cylinder"));
    QAction* Torus = new QAction(QIcon(":/Resources/torus.png"), tr("Torus"));
    QAction* Fillet = new QAction(QIcon(":/Resources/fillet.png"), tr("Fillet"));
    QAction* Chamfer = new QAction(QIcon(":/Resources/chamfer.png"), tr("Chamfer"));
    QAction* Extrude = new QAction(QIcon(":/Resources/extrude.png"), tr("Extrude"));
    QAction* Rovelve = new QAction(QIcon(":/Resources/rovelve.png"), tr("Rovelve"));
    QAction* Loft = new QAction(QIcon(":/Resources/loft.png"), tr("Loft"));
    QAction* Color = new QAction(QIcon(":/Resources/color.png"), tr("Color"));
    QMenu* Coarseness = new QMenu("Coarseness");

    Coarseness->setIcon(QIcon(":/Resources/coarseness.png"));
    QAction* width_1 = new QAction(QIcon(":/Resources/coarseness.png"), tr("width 1.0"));
    QAction* width_5 = new QAction(QIcon(":/Resources/coarseness.png"), tr("width 5.0"));
    QAction* width_10 = new QAction(QIcon(":/Resources/coarseness.png"), tr("width 10.0"));
    QAction* width_15 = new QAction(QIcon(":/Resources/coarseness.png"), tr("width 15.0"));
    width_1->setObjectName("0");
    width_5->setObjectName("1");
    width_10->setObjectName("2");
    width_15->setObjectName("3");
    QMenu* Transparency = new QMenu("Transparency");
    Transparency->setIcon(QIcon(":/Resources/transparency.png"));

    QSlider *sliderCoarseness = new QSlider(Qt::Horizontal, this);
    sliderCoarseness->setRange(1, 20);
    sliderCoarseness->setValue(10);
    QWidgetAction *sliderCoarsenessAction = new QWidgetAction(Coarseness);
    sliderCoarsenessAction->setDefaultWidget(sliderCoarseness);

    QSlider *sliderTransparency = new QSlider(Qt::Horizontal, this);
    sliderTransparency->setRange(0.0, 100.0);
    sliderTransparency->setValue(0.0);
    QWidgetAction *sliderTransparencyAction = new QWidgetAction(Transparency);
    sliderTransparencyAction->setDefaultWidget(sliderTransparency);

    QAction* Delete = new QAction(QIcon(":/Resources/delete.png"), tr("Delete"));
    QAction* Operate = new QAction(QIcon(":/Resources/move.png"), tr("Operate"));

    Coarseness->addAction(width_1);
    Coarseness->addAction(width_5);
    Coarseness->addAction(width_10);
    Coarseness->addAction(width_15);
    Coarseness->addAction(sliderCoarsenessAction);
    Transparency->addAction(sliderTransparencyAction);
    pannel4->addAction(Point, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel4->addAction(Line, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel4->addAction(Continuous, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel4->addAction(Face, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel5->addAction(Box, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel5->addAction(Cone, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel5->addAction(Sphere, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel5->addAction(Cylinder, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel5->addAction(Torus, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel5->addAction(Fillet, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel5->addAction(Chamfer, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel5->addAction(Extrude, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel5->addAction(Rovelve, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel5->addAction(Loft, QToolButton::InstantPopup, SARibbonPannelItem::Medium);
    pannel6->addAction(Color, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel6->addMenu(Coarseness, SARibbonPannelItem::RowProportion::Large);
    pannel6->addMenu(Transparency, SARibbonPannelItem::RowProportion::Large);
    pannel6->addAction(Delete, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel6->addAction(Operate, QToolButton::InstantPopup, SARibbonPannelItem::Large);

    SARibbonPannel* pannel7  = categoryPaint->addPannel(tr("Finish"));

    pannel7->setVisible(visible);

    connect(Point, &QAction::triggered, this, [=](){
        if(!visible){
            pointDockWidget(pannel7);
            myOccView->Point();
            myOccView->DirectionX_Y();
        }
        else
            QMessageBox::warning(this, tr("Woring"),tr("Please end the previous operation."), QMessageBox::Abort);

    });
    connect(Line,&QAction::triggered,this,[=](){
        if(!visible){
            lineDockWidget(pannel7);
            myOccView->Line();
            myOccView->DirectionX_Y();
        }
        else
            QMessageBox::warning(this, tr("Woring"),tr("Please end the previous operation."), QMessageBox::Abort);
    });
    connect(Continuous,&QAction::triggered,this,[=](){
        if(!visible){
            continuousFinish(pannel7);
            myOccView->Continuous();
            myOccView->DirectionX_Y();
        }
        else
            QMessageBox::warning(this, tr("Woring"),tr("Please end the previous operation."), QMessageBox::Abort);

    });
    connect(Face,&QAction::triggered,this,[=](){
       bool result = myOccView->makeFace();
       if(!result)
           QMessageBox::warning(this, tr("Woring"),tr("Please select a wire."), QMessageBox::Abort);
    });
    connect(Box,&QAction::triggered,this,[=](){makeBox();});
    connect(Cone,&QAction::triggered,this,[=](){qDebug()  << "do something";});
    connect(Sphere,&QAction::triggered,this,[=](){qDebug()  << "do something";});
    connect(Cylinder,&QAction::triggered,this,[=](){qDebug()  << "do something";});
    connect(Torus,&QAction::triggered,this,[=](){qDebug()  << "do something";});
    connect(Fillet,&QAction::triggered,this,[=](){qDebug()  << "do something";});
    connect(Chamfer,&QAction::triggered,this,[=](){qDebug()  << "do something";});
    connect(Extrude,&QAction::triggered,this,[=](){qDebug()  << "do something";});
    connect(Rovelve,&QAction::triggered,this,[=](){qDebug()  << "do something";});
    connect(Loft,&QAction::triggered,this,[=](){qDebug()  << "do something";});
    connect(Color, &QAction::triggered, this, [=](){mypaint->setColor();});
    connect(width_1, &QAction::triggered, this, [=](){mypaint->setWidth(1.0);});
    connect(width_5, &QAction::triggered, this, [=](){mypaint->setWidth(5.0);});
    connect(width_10, &QAction::triggered, this, [=](){mypaint->setWidth(10.0);});
    connect(width_15, &QAction::triggered, this, [=](){mypaint->setWidth(15.0);});
    connect(sliderCoarseness, &QSlider::valueChanged, this, [=](int value){mypaint->setWidth(value);});
    connect(sliderTransparency, &QSlider::valueChanged, this, [=](int value){mypaint->setTransparency(value);});
    connect(Delete,&QAction::triggered,this,[=](){
        QVector<Handle(AIS_Shape)> shapes = myPoint->deletePoint();
        undoStack->push(new DeleteCommand(shapes, myOccView->getContext()));
        myOccView->redraw();
    });

    connect(Operate,&QAction::triggered,this,[=](){

        bool isTrue = myPoint->Manipulator();
        if(isTrue){
            if(!visible){
                myOccView->Moving();
                manipulatorFinish(pannel7);
            }
            else
                QMessageBox::warning(this, tr("Woring"),tr("Please end the previous operation."), QMessageBox::Abort);
        }
    });


}
void occQt::MethodInit(SARibbonBar* bar){
    SARibbonCategory* categoryMethod = bar->addCategoryPage(tr("&Method"));
    categoryMethod->setObjectName(("categoryMethod"));

    SARibbonPannel* pannel8  = categoryMethod->addPannel(tr("Calculation"));

    QAction* Lofting = new QAction(QIcon(":/Resources/lofting.png"), tr("Lofting"));
    QAction* Stitch = new QAction(QIcon(":/Resources/stitch.png"), tr("Stitch"));
    QAction* Area = new QAction(QIcon(":/Resources/area.png"), tr("Area"));
    QAction* Volume = new QAction(QIcon(":/Resources/volume.png"), tr("Volume"));

    QMenu* Net = new QMenu("Convex Hull");
    Net->setIcon(QIcon(":/Resources/net.png"));
    QAction* reference_X = new QAction(QIcon(":/Resources/x.png"), tr("Reference X"));
    QAction* reference_Y = new QAction(QIcon(":/Resources/y.png"), tr("Reference Y"));
    QAction* reference_Z = new QAction(QIcon(":/Resources/z.png"), tr("Reference Z"));
    Net->addAction(reference_X);
    Net->addAction(reference_Y);
    Net->addAction(reference_Z);

    pannel8->addAction(Lofting, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel8->addAction(Stitch, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel8->addAction(Area, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel8->addAction(Volume, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel8->addMenu(Net, SARibbonPannelItem::RowProportion::Large);

    connect(Lofting,&QAction::triggered,this,[=](){
        Handle(AIS_Shape) myLofting = myLine->makeLofting();
        if(!myLofting.IsNull()){
            QUndoCommand *addCommand = new AddCommand(myLofting, myOccView->getContext());
            undoStack->push(addCommand);
        }
        else
            QMessageBox::warning(this, tr("Woring"),tr("The selected face or wireframe is less than 2."), QMessageBox::Abort);
    });
    connect(Stitch,&QAction::triggered,this,[=](){
        myOccView->makeSolid();
    });
    connect(Area,&QAction::triggered,this,[=](){
        double volume = myFace->calculateArea();
        if(volume != 0)
            QMessageBox::information(this, tr("Area value"),QString::number(abs(volume)), QMessageBox::Ok);
        else
            QMessageBox::warning(this, tr("Woring"),tr("Area is zero,Shape cannot be a point or a line."), QMessageBox::Abort);
    });
    connect(Volume,&QAction::triggered,this,[=](){
        double volume = myFace->calculateVolume();
        if(volume != 0)
            QMessageBox::information(this, tr("Volume value"),QString::number(abs(volume)), QMessageBox::Ok);
        else
            QMessageBox::warning(this, tr("Woring"),tr("Volume is zero,The shape must be solid."), QMessageBox::Abort);
    });

    connect(reference_X,&QAction::triggered,this,[=](){myOccView->getPoints('x');});
    connect(reference_Y,&QAction::triggered,this,[=](){myOccView->getPoints('y');});
    connect(reference_Z,&QAction::triggered,this,[=](){myOccView->getPoints('z');});
}

void occQt::pointDockWidget(SARibbonPannel* pannel7){
    QDockWidget *dockWidget = new QDockWidget("Point Manager", this);

    QWidget *dockContents = new QWidget(dockWidget);
    QFormLayout *layout = new QFormLayout(dockContents);

    QLabel *label = new QLabel("Coordinate", dockContents);
    layout->addRow(label);

    QLineEdit *xEdit = new QLineEdit("0",dockContents);
    layout->addRow("x", xEdit);
    QDoubleValidator *validator = new QDoubleValidator(xEdit);
    validator->setNotation(QDoubleValidator::StandardNotation);
    xEdit->setValidator(validator);

    QLineEdit *yEdit = new QLineEdit("0",dockContents);
    yEdit->setValidator(validator);
    layout->addRow("y", yEdit);

    QLineEdit *zEdit = new QLineEdit("0",dockContents);
    zEdit->setValidator(validator);
    layout->addRow("z", zEdit);

    dockContents->setLayout(layout);

    dockWidget->setWidget(dockContents);

    addDockWidget(Qt::RightDockWidgetArea, dockWidget);

    //SARibbonPannel* pannel7  = categoryPaint->addPannel(tr("Finish"));
    pannel7->setVisible(true);
    visible = true;
    QAction* finish = new QAction(QIcon(":/Resources/finish.png"), tr("Finish"));

    pannel7->addAction(finish, QToolButton::InstantPopup, SARibbonPannelItem::Large);

    connect(finish,&QAction::triggered,this,[=](){
        pannel7->setVisible(false);
        visible = false;
        finish->setVisible(false);
        dockWidget->setVisible(false);
        myOccView->pan();
        myOccView->redraw();

    });

    connect(xEdit, &QLineEdit::returnPressed,this,[=](){
        double x = xEdit->text().toDouble();
        double y = yEdit->text().toDouble();
        double z = zEdit->text().toDouble();
        gp_Pnt point(x,y,z);
        Handle(AIS_Shape) shape = myPoint->addPoint(point);
        QUndoCommand *addCommand = new AddCommand(shape, myOccView->getContext());
        undoStack->push(addCommand);
    });
    connect(yEdit, &QLineEdit::returnPressed,this,[=](){
        double x = xEdit->text().toDouble();
        double y = yEdit->text().toDouble();
        double z = zEdit->text().toDouble();
        gp_Pnt point(x,y,z);
        Handle(AIS_Shape) shape = myPoint->addPoint(point);
        undoStack->push(new AddCommand(shape, myOccView->getContext()));
    });
    connect(zEdit, &QLineEdit::returnPressed,this,[=](){
        double x = xEdit->text().toDouble();
        double y = yEdit->text().toDouble();
        double z = zEdit->text().toDouble();
        gp_Pnt point(x,y,z);
        Handle(AIS_Shape) shape = myPoint->addPoint(point);
        undoStack->push(new AddCommand(shape, myOccView->getContext()));
    });
}

void occQt::lineDockWidget(SARibbonPannel* pannel7){
    QDockWidget *dockWidget = new QDockWidget("Line Manager", this);

    QWidget *dockContents = new QWidget(dockWidget);
    QFormLayout *layout = new QFormLayout(dockContents);

    QLabel *label = new QLabel("First Coordinate", dockContents);
    layout->addRow(label);

    QLineEdit *xEdit = new QLineEdit("0",dockContents);
    layout->addRow("first x", xEdit);
    QDoubleValidator *validator = new QDoubleValidator(xEdit);
    validator->setNotation(QDoubleValidator::StandardNotation);
    xEdit->setValidator(validator);

    QLineEdit *yEdit = new QLineEdit("0",dockContents);
    yEdit->setValidator(validator);
    layout->addRow("first y", yEdit);

    QLineEdit *zEdit = new QLineEdit("0",dockContents);
    zEdit->setValidator(validator);
    layout->addRow("first z", zEdit);

    QLabel *secondLabel = new QLabel("Second Coordinate", dockContents);
    layout->addRow(secondLabel);

    QLineEdit *xSecondEdit = new QLineEdit("0",dockContents);
    xSecondEdit->setValidator(validator);
    layout->addRow("second x", xSecondEdit);

    QLineEdit *ySecondEdit = new QLineEdit("0",dockContents);
    ySecondEdit->setValidator(validator);
    layout->addRow("second y", ySecondEdit);

    QLineEdit *zSecondEdit = new QLineEdit("0",dockContents);
    zSecondEdit->setValidator(validator);
    layout->addRow("second z", zSecondEdit);

    dockContents->setLayout(layout);

    dockWidget->setWidget(dockContents);

    addDockWidget(Qt::RightDockWidgetArea, dockWidget);

    //SARibbonPannel* pannel7  = categoryPaint->addPannel(tr("Finish"));
    pannel7->setVisible(true);
    visible = true;
    QAction* finish = new QAction(QIcon(":/Resources/finish.png"), tr("Finish"));

    pannel7->addAction(finish, QToolButton::InstantPopup, SARibbonPannelItem::Large);

    connect(finish,&QAction::triggered,this,[=](){
        pannel7->setVisible(false);
        visible = false;
        finish->setVisible(false);
        dockWidget->setVisible(false);
        myOccView->pan();
        myOccView->redraw();
    });

    connect(xEdit, &QLineEdit::returnPressed,this,[=](){
        double x = xEdit->text().toDouble();
        double y = yEdit->text().toDouble();
        double z = zEdit->text().toDouble();
        double xSecond = xSecondEdit->text().toDouble();
        double ySecond = ySecondEdit->text().toDouble();
        double zSecond = zSecondEdit->text().toDouble();
        gp_Pnt firstPoint(x,y,z);
        gp_Pnt secondPoint(xSecond,ySecond,zSecond);

        Handle(AIS_Shape) shape = myLine->addLine(firstPoint, secondPoint);
        if(!shape.IsNull()){
            QUndoCommand *addCommand = new AddCommand(shape, myOccView->getContext());
            undoStack->push(addCommand);
        }
    });
    connect(yEdit, &QLineEdit::returnPressed,this,[=](){
        double x = xEdit->text().toDouble();
        double y = yEdit->text().toDouble();
        double z = zEdit->text().toDouble();
        double xSecond = xSecondEdit->text().toDouble();
        double ySecond = ySecondEdit->text().toDouble();
        double zSecond = zSecondEdit->text().toDouble();
        gp_Pnt firstPoint(x,y,z);
        gp_Pnt secondPoint(xSecond,ySecond,zSecond);

        Handle(AIS_Shape) shape = myLine->addLine(firstPoint, secondPoint);
        if(!shape.IsNull()){
            QUndoCommand *addCommand = new AddCommand(shape, myOccView->getContext());
            undoStack->push(addCommand);
        }
    });
    connect(zEdit, &QLineEdit::returnPressed,this,[=](){
        double x = xEdit->text().toDouble();
        double y = yEdit->text().toDouble();
        double z = zEdit->text().toDouble();
        double xSecond = xSecondEdit->text().toDouble();
        double ySecond = ySecondEdit->text().toDouble();
        double zSecond = zSecondEdit->text().toDouble();
        gp_Pnt firstPoint(x,y,z);
        gp_Pnt secondPoint(xSecond,ySecond,zSecond);

        Handle(AIS_Shape) shape = myLine->addLine(firstPoint, secondPoint);
        if(!shape.IsNull()){
            QUndoCommand *addCommand = new AddCommand(shape, myOccView->getContext());
            undoStack->push(addCommand);
        }
    });
    connect(xSecondEdit, &QLineEdit::returnPressed,this,[=](){
        double x = xEdit->text().toDouble();
        double y = yEdit->text().toDouble();
        double z = zEdit->text().toDouble();
        double xSecond = xSecondEdit->text().toDouble();
        double ySecond = ySecondEdit->text().toDouble();
        double zSecond = zSecondEdit->text().toDouble();
        gp_Pnt firstPoint(x,y,z);
        gp_Pnt secondPoint(xSecond,ySecond,zSecond);

        Handle(AIS_Shape) shape = myLine->addLine(firstPoint, secondPoint);
        if(!shape.IsNull()){
            QUndoCommand *addCommand = new AddCommand(shape, myOccView->getContext());
            undoStack->push(addCommand);
        }
    });
    connect(ySecondEdit, &QLineEdit::returnPressed,this,[=](){
        double x = xEdit->text().toDouble();
        double y = yEdit->text().toDouble();
        double z = zEdit->text().toDouble();
        double xSecond = xSecondEdit->text().toDouble();
        double ySecond = ySecondEdit->text().toDouble();
        double zSecond = zSecondEdit->text().toDouble();
        gp_Pnt firstPoint(x,y,z);
        gp_Pnt secondPoint(xSecond,ySecond,zSecond);

        Handle(AIS_Shape) shape = myLine->addLine(firstPoint, secondPoint);
        if(!shape.IsNull()){
            QUndoCommand *addCommand = new AddCommand(shape, myOccView->getContext());
            undoStack->push(addCommand);
        }
    });
    connect(zSecondEdit, &QLineEdit::returnPressed,this,[=](){
        double x = xEdit->text().toDouble();
        double y = yEdit->text().toDouble();
        double z = zEdit->text().toDouble();
        double xSecond = xSecondEdit->text().toDouble();
        double ySecond = ySecondEdit->text().toDouble();
        double zSecond = zSecondEdit->text().toDouble();
        gp_Pnt firstPoint(x,y,z);
        gp_Pnt secondPoint(xSecond,ySecond,zSecond);

        Handle(AIS_Shape) shape = myLine->addLine(firstPoint, secondPoint);
        if(!shape.IsNull()){
            QUndoCommand *addCommand = new AddCommand(shape, myOccView->getContext());
            undoStack->push(addCommand);
        }
    });
}

void occQt::continuousFinish(SARibbonPannel* pannel7){
    //SARibbonPannel* pannel7  = categoryPaint->addPannel(tr("Finish"));
    pannel7->setVisible(true);
    visible = true;
    QAction* finish = new QAction(QIcon(":/Resources/finish.png"), tr("Finish"));
    QAction* close = new QAction(QIcon(":/Resources/close.png"), tr("Close"));

    pannel7->addAction(finish, QToolButton::InstantPopup, SARibbonPannelItem::Large);
    pannel7->addAction(close, QToolButton::InstantPopup, SARibbonPannelItem::Large);

    connect(finish,&QAction::triggered,this,[=](){
        QVector<Handle(AIS_Shape)> Lines = myOccView->getLinesForWire();
        undoStack->push(new DeleteCommand(Lines, myOccView->getContext()));
        //myOccView->redraw();
        myOccView->clearnLines();
        //qDebug()<<Lines.size();
        //Lines.pop_back();
        Handle(AIS_Shape) Wire = myLine->makeWire(Lines);
        if(!Wire.IsNull()){
            QUndoCommand *addCommand = new AddCommand(Wire, myOccView->getContext());
            undoStack->push(addCommand);
        }
        pannel7->setVisible(false);
        visible = false;
        finish->setVisible(false);
        close->setVisible(false);
        myOccView->pan();
        myOccView->redraw();
    });

    connect(close,&QAction::triggered,this,[=](){
        myOccView->closeWire();
    });

}

void occQt::manipulatorFinish(SARibbonPannel* pannel7){
    //SARibbonPannel* pannel7  = categoryPaint->addPannel(tr("Finish"));
    pannel7->setVisible(true);
    visible = true;
    QAction* finish = new QAction(QIcon(":/Resources/finish.png"), tr("Finish"));

    pannel7->addAction(finish, QToolButton::InstantPopup, SARibbonPannelItem::Large);

    connect(finish,&QAction::triggered,this,[=](){
        pannel7->setVisible(false);
        visible = false;
        finish->setVisible(false);
        myOccView->pan();
        myOccView->splitManipulator();
        myOccView->redraw();
    });
}

void occQt::makeBox()
{
    TopoDS_Shape aTopoBox = BRepPrimAPI_MakeBox(1, 1, 1).Shape();
    Handle(AIS_Shape) anAisBox = new AIS_Shape(aTopoBox);

    anAisBox->SetColor(Quantity_NOC_AZURE);

    myOccView->getContext()->Display(anAisBox, Standard_True);
}
